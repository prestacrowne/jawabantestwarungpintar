import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.ebay.com/')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Testmultiplefilter/01_clickshopbycategory'))

WebUI.click(findTestObject('Testmultiplefilter/02_clickcellphonesandaccesories'))

WebUI.click(findTestObject('Testmultiplefilter/03_clickcellphoneandsmartphone'))

WebUI.scrollToElement(findTestObject('Testmultiplefilter/04_allfilters'), 0)

WebUI.click(findTestObject('Testmultiplefilter/04_allfilters'))

WebUI.click(findTestObject('Testmultiplefilter/05_clickscreensize'))

WebUI.click(findTestObject('Testmultiplefilter/06_click5.0-5.4'))

WebUI.click(findTestObject('Testmultiplefilter/07_clickprice'), FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Testmultiplefilter/08_clickfrom'))

WebUI.setText(findTestObject('Testmultiplefilter/08_clickfrom'), '1000000')

WebUI.click(findTestObject('Testmultiplefilter/09_clickto'))

WebUI.setText(findTestObject('Testmultiplefilter/09_clickto'), '3000000')

WebUI.click(findTestObject('Testmultiplefilter/10_clickitemlocation'))

WebUI.click(findTestObject('Testmultiplefilter/11_clickasia'))

WebUI.click(findTestObject('Testmultiplefilter/12_clickapply'))

